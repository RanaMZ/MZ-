<?php
include 'ip.php';
header('Location: user.php');
exit
?>
